# کنکور پلنر — اپلیکیشن حرفه‌ای برنامه‌ریزی مطالعه کنکور

اپلیکیشن Android (Flutter) برای مدیریت مطالعه، تست، مرور، عقب‌افتادگی و تحلیل پیشرفت کنکور.

## ویژگی‌های پیاده‌سازی‌شده (واقعی و کارکردی)

- ✅ Onboarding حرفه‌ای + ساخت پروفایل دانش‌آموز
- ✅ Dashboard Premium با Progress Ring، Streak، آمار امروز
- ✅ ساخت و مدیریت Task (دستی) با انواع فعالیت
- ✅ سیستم عقب‌افتادگی (انتقال خودکار / دستی / حذف)
- ✅ تقویم ماهانه با Indicator وضعیت روزها
- ✅ تایمر مطالعه واقعی + ثبت خودکار جلسه و XP
- ✅ آمار و نمودار هفتگی + کارت دروس با درصد تسلط
- ✅ پروفایل + Dark / Light Mode
- ✅ ذخیره‌سازی محلی با Hive (آفلاین)
- ✅ RTL کامل + فونت فارسی
- ✅ Design System اختصاصی (Minimal + Premium)

## ویژگی‌هایی که اسکلت دارند / نسخه بعدی

- برنامه‌ریز هوشمند کامل (الگوریتم پیشرفته)
- AI Assistant (اتصال به مدل)
- سیستم مرور فاصله‌دار کامل
- اعلان‌های محلی
- Cloud Sync
- Pomodoro پیشرفته

## نحوه اجرا (مهم)

### پیش‌نیازها
1. نصب [Flutter SDK](https://docs.flutter.dev/get-started/install) (نسخه ۳.۱۶ یا بالاتر)
2. Android Studio + Android SDK
3. یک امولاتور یا گوشی Android

### مراحل

```bash
# ۱. دانلود و استخراج پروژه
cd konkur_planner

# ۲. دانلود فونت فارسی (الزامی)
# از https://github.com/rastikerdar/vazirmatn/releases
# فایل‌های زیر را در assets/fonts/ قرار دهید:
#   Vazirmatn-Regular.ttf
#   Vazirmatn-Medium.ttf
#   Vazirmatn-SemiBold.ttf
#   Vazirmatn-Bold.ttf

# ۳. نصب dependencyها
flutter pub get

# ۴. (اختیاری) تولید کد Hive اگر تغییر دادید
# flutter pub run build_runner build --delete-conflicting-outputs

# ۵. اجرا روی دستگاه/امولاتور
flutter run

# ۶. ساخت APK قابل نصب
flutter build apk --release
# فایل خروجی:
# build/app/outputs/flutter-apk/app-release.apk
```

### ساخت APK بدون فونت سفارشی
اگر فونت Vazirmatn را اضافه نکردید، در `pubspec.yaml` بخش `fonts` را کامنت کنید و در theme از `fontFamily: null` یا فونت سیستم استفاده کنید. اپ همچنان با فونت پیش‌فرض سیستم کار می‌کند.

## ساختار پروژه

```
lib/
├── core/           # Theme, widgets, services
├── data/           # Models + Hive local DB
├── domain/         # (آماده برای توسعه)
├── features/
│   ├── onboarding/
│   ├── dashboard/
│   ├── planner/
│   ├── calendar/
│   ├── stats/
│   ├── profile/
│   ├── timer/
│   └── ...
├── app.dart
└── main.dart
```

## نکات طراحی

- Design System کامل در `lib/core/theme/`
- رنگ اصلی: Indigo `#4F46E5`
- Dark Mode با سطوح Surface لایه‌ای
- Spacing 8pt، Radius 12/16/24
- Bottom Navigation ۵ تب

## لایسنس
این پروژه برای استفاده آموزشی و شخصی ارائه شده است.
 ساخته‌شده برای دانش‌آموزان کنکوری ایران.
