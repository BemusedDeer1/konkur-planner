import 'package:flutter/material.dart';
import 'app_colors.dart';

class AppTypography {
  static const String fontFamily = 'Roboto';

  static const TextStyle displayLarge = TextStyle(
    fontFamily: fontFamily,
    fontSize: 32,
    fontWeight: FontWeight.w700,
    height: 1.25,
    letterSpacing: -0.5,
  );

  static const TextStyle displayMedium = TextStyle(
    fontFamily: fontFamily,
    fontSize: 28,
    fontWeight: FontWeight.w700,
    height: 1.3,
  );

  static const TextStyle headingLarge = TextStyle(
    fontFamily: fontFamily,
    fontSize: 22,
    fontWeight: FontWeight.w700,
    height: 1.35,
  );

  static const TextStyle headingMedium = TextStyle(
    fontFamily: fontFamily,
    fontSize: 18,
    fontWeight: FontWeight.w600,
    height: 1.4,
  );

  static const TextStyle headingSmall = TextStyle(
    fontFamily: fontFamily,
    fontSize: 16,
    fontWeight: FontWeight.w600,
    height: 1.4,
  );

  static const TextStyle bodyLarge = TextStyle(
    fontFamily: fontFamily,
    fontSize: 16,
    fontWeight: FontWeight.w400,
    height: 1.5,
  );

  static const TextStyle bodyMedium = TextStyle(
    fontFamily: fontFamily,
    fontSize: 14,
    fontWeight: FontWeight.w400,
    height: 1.5,
  );

  static const TextStyle bodySmall = TextStyle(
    fontFamily: fontFamily,
    fontSize: 13,
    fontWeight: FontWeight.w400,
    height: 1.45,
  );

  static const TextStyle caption = TextStyle(
    fontFamily: fontFamily,
    fontSize: 12,
    fontWeight: FontWeight.w400,
    height: 1.4,
  );

  static const TextStyle label = TextStyle(
    fontFamily: fontFamily,
    fontSize: 12,
    fontWeight: FontWeight.w500,
    height: 1.3,
  );

  static const TextStyle numberLarge = TextStyle(
    fontFamily: fontFamily,
    fontSize: 36,
    fontWeight: FontWeight.w700,
    height: 1.1,
  );

  static const TextStyle numberMedium = TextStyle(
    fontFamily: fontFamily,
    fontSize: 24,
    fontWeight: FontWeight.w700,
    height: 1.2,
  );

  static TextTheme get textThemeLight => TextTheme(
        displayLarge: displayLarge.copyWith(color: AppColors.textPrimaryLight),
        displayMedium: displayMedium.copyWith(color: AppColors.textPrimaryLight),
        headlineLarge: headingLarge.copyWith(color: AppColors.textPrimaryLight),
        headlineMedium: headingMedium.copyWith(color: AppColors.textPrimaryLight),
        headlineSmall: headingSmall.copyWith(color: AppColors.textPrimaryLight),
        bodyLarge: bodyLarge.copyWith(color: AppColors.textPrimaryLight),
        bodyMedium: bodyMedium.copyWith(color: AppColors.textSecondaryLight),
        bodySmall: bodySmall.copyWith(color: AppColors.textSecondaryLight),
        labelLarge: label.copyWith(color: AppColors.textPrimaryLight),
        labelMedium: caption.copyWith(color: AppColors.textSecondaryLight),
        labelSmall: caption.copyWith(color: AppColors.textTertiaryLight),
      );

  static TextTheme get textThemeDark => TextTheme(
        displayLarge: displayLarge.copyWith(color: AppColors.textPrimaryDark),
        displayMedium: displayMedium.copyWith(color: AppColors.textPrimaryDark),
        headlineLarge: headingLarge.copyWith(color: AppColors.textPrimaryDark),
        headlineMedium: headingMedium.copyWith(color: AppColors.textPrimaryDark),
        headlineSmall: headingSmall.copyWith(color: AppColors.textPrimaryDark),
        bodyLarge: bodyLarge.copyWith(color: AppColors.textPrimaryDark),
        bodyMedium: bodyMedium.copyWith(color: AppColors.textSecondaryDark),
        bodySmall: bodySmall.copyWith(color: AppColors.textSecondaryDark),
        labelLarge: label.copyWith(color: AppColors.textPrimaryDark),
        labelMedium: caption.copyWith(color: AppColors.textSecondaryDark),
        labelSmall: caption.copyWith(color: AppColors.textTertiaryDark),
      );
}
