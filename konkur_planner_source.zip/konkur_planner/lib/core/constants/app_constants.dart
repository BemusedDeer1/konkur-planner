class AppConstants {
  static const String appName = 'کنکور پلنر';
  static const String appVersion = '1.0.0';
}
