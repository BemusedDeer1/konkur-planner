import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/task.dart';

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  late DateTime _focusedMonth;
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _focusedMonth = DateTime(DateTime.now().year, DateTime.now().month);
    _selectedDay = DateTime.now();
  }

  Map<DateTime, List<StudyTask>> get _tasksByDay {
    final map = <DateTime, List<StudyTask>>{};
    for (final t in HiveService.tasks.values) {
      final key = DateTime(t.scheduledDate.year, t.scheduledDate.month, t.scheduledDate.day);
      map.putIfAbsent(key, () => []).add(t);
    }
    return map;
  }

  Color _dayStatusColor(DateTime day) {
    final key = DateTime(day.year, day.month, day.day);
    final tasks = _tasksByDay[key];
    if (tasks == null || tasks.isEmpty) return Colors.transparent;
    final completed = tasks.where((t) => t.status == TaskStatus.completed).length;
    if (completed == tasks.length) return AppColors.complete;
    if (tasks.any((t) => t.status == TaskStatus.missed)) return AppColors.missed;
    if (completed > 0) return AppColors.partial;
    return AppColors.planned;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final daysInMonth = DateTime(_focusedMonth.year, _focusedMonth.month + 1, 0).day;
    final firstWeekday = DateTime(_focusedMonth.year, _focusedMonth.month, 1).weekday % 7;

    return Scaffold(
      appBar: AppBar(
        title: const Text('تقویم'),
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.chevronRight),
            onPressed: () {
              setState(() {
                _focusedMonth = DateTime(_focusedMonth.year, _focusedMonth.month - 1);
              });
            },
          ),
          Text(
            '${_focusedMonth.year}/${_focusedMonth.month}',
            style: AppTypography.headingSmall,
          ),
          IconButton(
            icon: const Icon(LucideIcons.chevronLeft),
            onPressed: () {
              setState(() {
                _focusedMonth = DateTime(_focusedMonth.year, _focusedMonth.month + 1);
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Weekday headers
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج']
                  .map((d) => Expanded(
                        child: Center(
                          child: Text(
                            d,
                            style: AppTypography.caption.copyWith(
                              color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
                            ),
                          ),
                        ),
                      ))
                  .toList(),
            ),
          ),
          // Grid
          Expanded(
            flex: 2,
            child: GridView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7,
                childAspectRatio: 1,
              ),
              itemCount: firstWeekday + daysInMonth,
              itemBuilder: (context, index) {
                if (index < firstWeekday) return const SizedBox();
                final day = index - firstWeekday + 1;
                final date = DateTime(_focusedMonth.year, _focusedMonth.month, day);
                final isSelected = _selectedDay != null &&
                    _selectedDay!.day == day &&
                    _selectedDay!.month == _focusedMonth.month;
                final isToday = date.day == DateTime.now().day &&
                    date.month == DateTime.now().month &&
                    date.year == DateTime.now().year;
                final statusColor = _dayStatusColor(date);

                return GestureDetector(
                  onTap: () => setState(() => _selectedDay = date),
                  child: Container(
                    margin: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.primary.withOpacity(0.15)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                      border: isToday
                          ? Border.all(color: AppColors.primary, width: 1.5)
                          : null,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '$day',
                          style: TextStyle(
                            fontWeight: isSelected || isToday ? FontWeight.w700 : FontWeight.w400,
                            color: isSelected
                                ? AppColors.primary
                                : (isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight),
                            fontFamily: 'Vazirmatn',
                          ),
                        ),
                        if (statusColor != Colors.transparent)
                          Container(
                            margin: const EdgeInsets.only(top: 4),
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: statusColor,
                              shape: BoxShape.circle,
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          // Legend
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _Legend(color: AppColors.complete, label: 'کامل'),
                _Legend(color: AppColors.partial, label: 'ناقص'),
                _Legend(color: AppColors.missed, label: 'عقب‌افتاده'),
                _Legend(color: AppColors.planned, label: 'برنامه‌ریزی'),
              ],
            ),
          ),
          // Selected day tasks
          Expanded(
            flex: 2,
            child: _selectedDay == null
                ? const SizedBox()
                : _DayTasksList(
                    date: _selectedDay!,
                    tasks: _tasksByDay[DateTime(_selectedDay!.year, _selectedDay!.month, _selectedDay!.day)] ?? [],
                    isDark: isDark,
                  ),
          ),
        ],
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;

  const _Legend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 4),
        Text(label, style: AppTypography.caption),
      ],
    );
  }
}

class _DayTasksList extends StatelessWidget {
  final DateTime date;
  final List<StudyTask> tasks;
  final bool isDark;

  const _DayTasksList({
    required this.date,
    required this.tasks,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isDark ? AppColors.borderDark : AppColors.borderLight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'برنامه ${date.day}/${date.month}',
            style: AppTypography.headingSmall,
          ),
          const SizedBox(height: 12),
          Expanded(
            child: tasks.isEmpty
                ? Center(
                    child: Text(
                      'برنامه‌ای ثبت نشده',
                      style: AppTypography.bodyMedium.copyWith(
                        color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
                      ),
                    ),
                  )
                : ListView.builder(
                    itemCount: tasks.length,
                    itemBuilder: (context, i) {
                      final t = tasks[i];
                      return ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        leading: Text(t.startTime, style: AppTypography.label),
                        title: Text(t.displayTitle, style: AppTypography.bodyMedium),
                        subtitle: Text('${t.activity.emoji} ${t.activity.label}'),
                        trailing: Icon(
                          t.status == TaskStatus.completed
                              ? LucideIcons.checkCircle2
                              : t.status == TaskStatus.missed
                                  ? LucideIcons.xCircle
                                  : LucideIcons.circle,
                          size: 18,
                          color: t.status == TaskStatus.completed
                              ? AppColors.success
                              : t.status == TaskStatus.missed
                                  ? AppColors.error
                                  : AppColors.textTertiaryLight,
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
