import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/subject.dart';

class StatsScreen extends ConsumerWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final subjects = HiveService.subjects.values.toList()
      ..sort((a, b) => a.orderIndex.compareTo(b.orderIndex));
    final sessions = HiveService.sessions.values.toList();

    final totalMinutes = sessions.fold<int>(0, (s, e) => s + (e.durationSeconds ~/ 60));
    final totalTests = sessions.fold<int>(0, (s, e) => s + e.testsDone);
    final totalCorrect = sessions.fold<int>(0, (s, e) => s + e.correct);

    // Weekly hours (last 7 days)
    final now = DateTime.now();
    final weeklyHours = List.generate(7, (i) {
      final day = now.subtract(Duration(days: 6 - i));
      final mins = sessions
          .where((s) =>
              s.startedAt.year == day.year &&
              s.startedAt.month == day.month &&
              s.startedAt.day == day.day)
          .fold<int>(0, (sum, s) => sum + (s.durationSeconds ~/ 60));
      return mins / 60.0;
    });

    return Scaffold(
      appBar: AppBar(title: const Text('آمار و تحلیل')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Summary cards
          Row(
            children: [
              Expanded(
                child: _SummaryCard(
                  icon: LucideIcons.clock,
                  label: 'مجموع مطالعه',
                  value: '${totalMinutes ~/ 60}س ${totalMinutes % 60}د',
                  color: AppColors.primary,
                  isDark: isDark,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SummaryCard(
                  icon: LucideIcons.fileText,
                  label: 'مجموع تست',
                  value: '$totalTests',
                  color: AppColors.secondary,
                  isDark: isDark,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _SummaryCard(
                  icon: LucideIcons.target,
                  label: 'درصد صحت',
                  value: totalTests > 0
                      ? '${((totalCorrect / totalTests) * 100).toStringAsFixed(0)}٪'
                      : '—',
                  color: AppColors.accent,
                  isDark: isDark,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SummaryCard(
                  icon: LucideIcons.flame,
                  label: 'Streak',
                  value: '${HiveService.currentUser?.currentStreak ?? 0} روز',
                  color: AppColors.warning,
                  isDark: isDark,
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),

          // Weekly chart
          Text('ساعات مطالعه هفتگی', style: AppTypography.headingMedium),
          const SizedBox(height: 16),
          Container(
            height: 200,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceLight,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isDark ? AppColors.borderDark : AppColors.borderLight,
              ),
            ),
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: (weeklyHours.reduce((a, b) => a > b ? a : b) + 1).clamp(4, 12),
                barTouchData: BarTouchData(enabled: true),
                titlesData: FlTitlesData(
                  show: true,
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        const days = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
                        return Text(
                          days[value.toInt() % 7],
                          style: AppTypography.caption,
                        );
                      },
                    ),
                  ),
                  leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                borderData: FlBorderData(show: false),
                gridData: const FlGridData(show: false),
                barGroups: List.generate(7, (i) {
                  return BarChartGroupData(
                    x: i,
                    barRods: [
                      BarChartRodData(
                        toY: weeklyHours[i],
                        color: AppColors.primary,
                        width: 18,
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
                      ),
                    ],
                  );
                }),
              ),
            ),
          ),
          const SizedBox(height: 28),

          // Subjects
          Text('وضعیت دروس', style: AppTypography.headingMedium),
          const SizedBox(height: 12),
          ...subjects.map((s) => _SubjectCard(subject: s, isDark: isDark)),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  final bool isDark;

  const _SummaryCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? AppColors.borderDark : AppColors.borderLight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(height: 12),
          Text(value, style: AppTypography.headingMedium),
          const SizedBox(height: 2),
          Text(
            label,
            style: AppTypography.caption.copyWith(
              color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
            ),
          ),
        ],
      ),
    );
  }
}

class _SubjectCard extends StatelessWidget {
  final Subject subject;
  final bool isDark;

  const _SubjectCard({required this.subject, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? AppColors.borderDark : AppColors.borderLight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(subject.iconName ?? '📘', style: const TextStyle(fontSize: 22)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(subject.name, style: AppTypography.headingSmall),
              ),
              Text(
                '${subject.masteryPercent.toStringAsFixed(0)}٪ تسلط',
                style: AppTypography.label.copyWith(color: subject.color),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: subject.masteryPercent / 100,
              backgroundColor: subject.color.withOpacity(0.15),
              valueColor: AlwaysStoppedAnimation(subject.color),
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(
                '${subject.totalTests} تست',
                style: AppTypography.caption,
              ),
              const SizedBox(width: 16),
              Text(
                '${subject.correctTests} صحیح',
                style: AppTypography.caption.copyWith(color: AppColors.success),
              ),
              const SizedBox(width: 16),
              Text(
                '${subject.wrongTests} غلط',
                style: AppTypography.caption.copyWith(color: AppColors.error),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
