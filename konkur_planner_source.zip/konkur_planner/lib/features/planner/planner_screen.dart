import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:uuid/uuid.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/task.dart';
import '../../data/models/subject.dart';

class PlannerScreen extends ConsumerStatefulWidget {
  const PlannerScreen({super.key});

  @override
  ConsumerState<PlannerScreen> createState() => _PlannerScreenState();
}

class _PlannerScreenState extends ConsumerState<PlannerScreen> {
  DateTime _selectedDate = DateTime.now();

  List<StudyTask> get _tasksForDay {
    return HiveService.tasks.values.where((t) {
      return t.scheduledDate.year == _selectedDate.year &&
          t.scheduledDate.month == _selectedDate.month &&
          t.scheduledDate.day == _selectedDate.day;
    }).toList()
      ..sort((a, b) => a.startTime.compareTo(b.startTime));
  }

  Future<void> _addTask() async {
    final subjects = HiveService.subjects.values.toList();
    if (subjects.isEmpty) return;

    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _AddTaskSheet(subjects: subjects, date: _selectedDate),
    );

    if (result != null) {
      final task = StudyTask(
        subjectId: result['subjectId'],
        subjectName: result['subjectName'],
        topicTitle: result['topic'],
        activity: result['activity'],
        scheduledDate: _selectedDate,
        startTime: result['startTime'],
        durationMinutes: result['duration'],
        targetTests: result['tests'],
      );
      await HiveService.tasks.put(task.id, task);
      setState(() {});
    }
  }

  Future<void> _completeTask(StudyTask task) async {
    task.status = TaskStatus.completed;
    task.actualDurationMinutes = task.durationMinutes;
    task.updatedAt = DateTime.now();
    await task.save();

    // Update streak & XP
    final user = HiveService.currentUser;
    if (user != null) {
      final today = DateTime.now();
      if (user.lastStudyDate == null ||
          user.lastStudyDate!.day != today.day ||
          user.lastStudyDate!.month != today.month) {
        user.currentStreak += 1;
        if (user.currentStreak > user.longestStreak) {
          user.longestStreak = user.currentStreak;
        }
        user.lastStudyDate = today;
      }
      user.xp += 50;
      user.level = 1 + (user.xp ~/ 500);
      await HiveService.saveUser(user);
    }
    setState(() {});
  }

  Future<void> _markMissed(StudyTask task) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(LucideIcons.calendarClock, color: AppColors.primary),
              title: const Text('انتقال خودکار به بهترین زمان'),
              onTap: () => Navigator.pop(ctx, 'auto'),
            ),
            ListTile(
              leading: const Icon(LucideIcons.calendar, color: AppColors.secondary),
              title: const Text('انتخاب زمان دستی'),
              onTap: () => Navigator.pop(ctx, 'manual'),
            ),
            ListTile(
              leading: const Icon(LucideIcons.trash2, color: AppColors.error),
              title: const Text('حذف Task'),
              onTap: () => Navigator.pop(ctx, 'delete'),
            ),
          ],
        ),
      ),
    );

    if (action == 'delete') {
      await task.delete();
    } else if (action == 'auto') {
      // Simple rule: move to next day same time
      final next = task.scheduledDate.add(const Duration(days: 1));
      task.scheduledDate = next;
      task.status = TaskStatus.rescheduled;
      task.updatedAt = DateTime.now();
      await task.save();
    } else if (action == 'manual') {
      // For simplicity, move to next day
      final next = task.scheduledDate.add(const Duration(days: 1));
      task.scheduledDate = next;
      task.status = TaskStatus.rescheduled;
      await task.save();
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final tasks = _tasksForDay;

    return Scaffold(
      appBar: AppBar(
        title: const Text('برنامه'),
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.sparkles),
            tooltip: 'بهینه‌سازی هوشمند',
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('برنامه بر اساس ظرفیت شما بهینه شد')),
              );
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addTask,
        icon: const Icon(LucideIcons.plus),
        label: const Text('Task جدید'),
        backgroundColor: AppColors.primary,
      ),
      body: Column(
        children: [
          // Date selector
          SizedBox(
            height: 90,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              itemCount: 14,
              itemBuilder: (context, index) {
                final date = DateTime.now().add(Duration(days: index - 3));
                final isSelected = date.day == _selectedDate.day &&
                    date.month == _selectedDate.month;
                final isToday = date.day == DateTime.now().day &&
                    date.month == DateTime.now().month;

                return GestureDetector(
                  onTap: () => setState(() => _selectedDate = date),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 56,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.primary
                          : (isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceElevatedLight),
                      borderRadius: BorderRadius.circular(16),
                      border: isToday && !isSelected
                          ? Border.all(color: AppColors.primary, width: 1.5)
                          : null,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          _weekdayShort(date.weekday),
                          style: TextStyle(
                            fontSize: 11,
                            color: isSelected
                                ? Colors.white70
                                : (isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight),
                            fontFamily: 'Vazirmatn',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${date.day}',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: isSelected
                                ? Colors.white
                                : (isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight),
                            fontFamily: 'Vazirmatn',
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: tasks.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          LucideIcons.calendarOff,
                          size: 56,
                          color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'برنامه‌ای برای این روز نیست',
                          style: AppTypography.headingSmall,
                        ),
                        const SizedBox(height: 8),
                        TextButton.icon(
                          onPressed: _addTask,
                          icon: const Icon(LucideIcons.plus),
                          label: const Text('اضافه کردن Task'),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                    itemCount: tasks.length,
                    itemBuilder: (context, index) {
                      final task = tasks[index];
                      return _TaskCard(
                        task: task,
                        isDark: isDark,
                        onComplete: () => _completeTask(task),
                        onMissed: () => _markMissed(task),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  String _weekdayShort(int weekday) {
    const days = ['دوش', 'سه', 'چها', 'پنج', 'جمع', 'شنب', 'یکش'];
    return days[weekday % 7];
  }
}

class _TaskCard extends StatelessWidget {
  final StudyTask task;
  final bool isDark;
  final VoidCallback onComplete;
  final VoidCallback onMissed;

  const _TaskCard({
    required this.task,
    required this.isDark,
    required this.onComplete,
    required this.onMissed,
  });

  @override
  Widget build(BuildContext context) {
    final isDone = task.status == TaskStatus.completed;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDone
              ? AppColors.success.withOpacity(0.4)
              : (isDark ? AppColors.borderDark : AppColors.borderLight),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                task.startTime,
                style: AppTypography.label.copyWith(color: AppColors.primary),
              ),
              const Spacer(),
              if (!isDone) ...[
                IconButton(
                  icon: const Icon(LucideIcons.check, size: 20, color: AppColors.success),
                  onPressed: onComplete,
                  tooltip: 'انجام شد',
                ),
                IconButton(
                  icon: const Icon(LucideIcons.x, size: 20, color: AppColors.error),
                  onPressed: onMissed,
                  tooltip: 'عقب‌افتاده',
                ),
              ] else
                const Icon(LucideIcons.checkCircle2, color: AppColors.success, size: 22),
            ],
          ),
          Text(
            task.displayTitle,
            style: AppTypography.headingSmall.copyWith(
              decoration: isDone ? TextDecoration.lineThrough : null,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '${task.activity.emoji} ${task.activity.label} · ${task.durationMinutes} دقیقه'
            '${task.targetTests != null ? ' · هدف: ${task.targetTests} تست' : ''}',
            style: AppTypography.caption.copyWith(
              color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
            ),
          ),
        ],
      ),
    );
  }
}

class _AddTaskSheet extends StatefulWidget {
  final List<Subject> subjects;
  final DateTime date;

  const _AddTaskSheet({required this.subjects, required this.date});

  @override
  State<_AddTaskSheet> createState() => _AddTaskSheetState();
}

class _AddTaskSheetState extends State<_AddTaskSheet> {
  late Subject _selectedSubject;
  TaskActivity _activity = TaskActivity.study;
  final _topicController = TextEditingController();
  final _timeController = TextEditingController(text: '16:00');
  int _duration = 90;
  int? _tests = 30;

  @override
  void initState() {
    super.initState();
    _selectedSubject = widget.subjects.first;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        top: 24,
        left: 20,
        right: 20,
      ),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceDark : AppColors.surfaceLight,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: isDark ? AppColors.borderDark : AppColors.borderLight,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text('Task جدید', style: AppTypography.headingMedium),
            const SizedBox(height: 20),
            DropdownButtonFormField<Subject>(
              value: _selectedSubject,
              decoration: const InputDecoration(labelText: 'درس'),
              items: widget.subjects
                  .map((s) => DropdownMenuItem(
                        value: s,
                        child: Text('${s.iconName ?? ''} ${s.name}'),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _selectedSubject = v!),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _topicController,
              decoration: const InputDecoration(
                labelText: 'مبحث (فصل / گفتار)',
                hintText: 'مثلاً فصل ۴ — گفتار ۱',
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<TaskActivity>(
              value: _activity,
              decoration: const InputDecoration(labelText: 'نوع فعالیت'),
              items: TaskActivity.values
                  .map((a) => DropdownMenuItem(
                        value: a,
                        child: Text('${a.emoji} ${a.label}'),
                      ))
                  .toList(),
              onChanged: (v) => setState(() => _activity = v!),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _timeController,
                    decoration: const InputDecoration(labelText: 'ساعت شروع'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: _duration,
                    decoration: const InputDecoration(labelText: 'مدت (دقیقه)'),
                    items: [30, 45, 60, 90, 120, 150]
                        .map((m) => DropdownMenuItem(value: m, child: Text('$m')))
                        .toList(),
                    onChanged: (v) => setState(() => _duration = v!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'تعداد تست هدف (اختیاری)',
                hintText: '۳۰',
              ),
              onChanged: (v) => _tests = int.tryParse(v),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context, {
                    'subjectId': _selectedSubject.id,
                    'subjectName': _selectedSubject.name,
                    'topic': _topicController.text.trim().isEmpty
                        ? null
                        : _topicController.text.trim(),
                    'activity': _activity,
                    'startTime': _timeController.text.trim(),
                    'duration': _duration,
                    'tests': _tests,
                  });
                },
                child: const Text('افزودن Task'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
