import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/subject.dart';
import '../../data/models/study_session.dart';
import '../../data/models/task.dart';

class TimerScreen extends ConsumerStatefulWidget {
  const TimerScreen({super.key});

  @override
  ConsumerState<TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends ConsumerState<TimerScreen> {
  Timer? _timer;
  int _seconds = 0;
  bool _isRunning = false;
  bool _isPaused = false;

  Subject? _selectedSubject;
  TaskActivity _activity = TaskActivity.study;
  final _topicController = TextEditingController();

  // After finish
  final _testsController = TextEditingController();
  final _correctController = TextEditingController();
  final _wrongController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final subjects = HiveService.subjects.values.toList();
    if (subjects.isNotEmpty) _selectedSubject = subjects.first;
  }

  @override
  void dispose() {
    _timer?.cancel();
    _topicController.dispose();
    _testsController.dispose();
    _correctController.dispose();
    _wrongController.dispose();
    super.dispose();
  }

  void _start() {
    if (_selectedSubject == null) return;
    setState(() {
      _isRunning = true;
      _isPaused = false;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _seconds++);
    });
  }

  void _pause() {
    _timer?.cancel();
    setState(() => _isPaused = true);
  }

  void _resume() {
    setState(() => _isPaused = false);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _seconds++);
    });
  }

  Future<void> _finish() async {
    _timer?.cancel();
    if (_seconds < 30) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('حداقل ۳۰ ثانیه مطالعه ثبت شود')),
      );
      setState(() {
        _isRunning = false;
        _isPaused = false;
      });
      return;
    }

    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => _FinishSheet(
        seconds: _seconds,
        testsController: _testsController,
        correctController: _correctController,
        wrongController: _wrongController,
      ),
    );

    if (result == true && _selectedSubject != null) {
      final tests = int.tryParse(_testsController.text) ?? 0;
      final correct = int.tryParse(_correctController.text) ?? 0;
      final wrong = int.tryParse(_wrongController.text) ?? 0;
      final blank = (tests - correct - wrong).clamp(0, tests);

      final session = StudySession(
        subjectId: _selectedSubject!.id,
        subjectName: _selectedSubject!.name,
        topicTitle: _topicController.text.trim().isEmpty ? null : _topicController.text.trim(),
        activityLabel: _activity.label,
        startedAt: DateTime.now().subtract(Duration(seconds: _seconds)),
        endedAt: DateTime.now(),
        durationSeconds: _seconds,
        testsDone: tests,
        correct: correct,
        wrong: wrong,
        blank: blank,
        xpEarned: 20 + (_seconds ~/ 60) * 2 + correct,
      );

      await HiveService.sessions.put(session.id, session);

      // Update subject stats
      _selectedSubject!.totalTests += tests;
      _selectedSubject!.correctTests += correct;
      _selectedSubject!.wrongTests += wrong;
      _selectedSubject!.blankTests += blank;
      _selectedSubject!.lastStudiedAt = DateTime.now();
      if (_selectedSubject!.totalTests > 0) {
        _selectedSubject!.masteryPercent =
            (_selectedSubject!.correctTests / _selectedSubject!.totalTests * 100);
      }
      await _selectedSubject!.save();

      // XP & streak
      final user = HiveService.currentUser;
      if (user != null) {
        user.xp += session.xpEarned;
        user.level = 1 + (user.xp ~/ 500);
        final today = DateTime.now();
        if (user.lastStudyDate == null ||
            user.lastStudyDate!.day != today.day ||
            user.lastStudyDate!.month != today.month) {
          user.currentStreak += 1;
          if (user.currentStreak > user.longestStreak) {
            user.longestStreak = user.currentStreak;
          }
          user.lastStudyDate = today;
        }
        await HiveService.saveUser(user);
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('جلسه ثبت شد · +${session.xpEarned} XP')),
        );
        Navigator.pop(context);
      }
    } else {
      setState(() {
        _isRunning = false;
        _isPaused = false;
      });
    }
  }

  String get _timeDisplay {
    final h = _seconds ~/ 3600;
    final m = (_seconds % 3600) ~/ 60;
    final s = _seconds % 60;
    if (h > 0) {
      return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
    }
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final subjects = HiveService.subjects.values.toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('تایمر مطالعه'),
        leading: IconButton(
          icon: const Icon(LucideIcons.x),
          onPressed: () {
            if (_isRunning) {
              showDialog(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('خروج؟'),
                  content: const Text('زمان فعلی ذخیره نمی‌شود.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ماندن')),
                    TextButton(
                      onPressed: () {
                        Navigator.pop(ctx);
                        Navigator.pop(context);
                      },
                      child: const Text('خروج'),
                    ),
                  ],
                ),
              );
            } else {
              Navigator.pop(context);
            }
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            if (!_isRunning) ...[
              DropdownButtonFormField<Subject>(
                value: _selectedSubject,
                decoration: const InputDecoration(labelText: 'درس'),
                items: subjects
                    .map((s) => DropdownMenuItem(
                          value: s,
                          child: Text('${s.iconName ?? ''} ${s.name}'),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _selectedSubject = v),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _topicController,
                decoration: const InputDecoration(
                  labelText: 'مبحث (اختیاری)',
                  hintText: 'فصل ۴ — گفتار ۱',
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<TaskActivity>(
                value: _activity,
                decoration: const InputDecoration(labelText: 'نوع فعالیت'),
                items: TaskActivity.values
                    .map((a) => DropdownMenuItem(
                          value: a,
                          child: Text('${a.emoji} ${a.label}'),
                        ))
                    .toList(),
                onChanged: (v) => setState(() => _activity = v!),
              ),
              const Spacer(),
            ] else ...[
              const Spacer(),
              Text(
                _selectedSubject?.name ?? '',
                style: AppTypography.headingMedium,
              ),
              if (_topicController.text.isNotEmpty)
                Text(
                  _topicController.text,
                  style: AppTypography.bodyMedium.copyWith(
                    color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight,
                  ),
                ),
              const SizedBox(height: 8),
              Text(
                '${_activity.emoji} ${_activity.label}',
                style: AppTypography.caption,
              ),
              const Spacer(),
            ],

            // Timer display
            Text(
              _timeDisplay,
              style: AppTypography.numberLarge.copyWith(
                fontSize: 64,
                color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
              ),
            ),
            const SizedBox(height: 40),

            // Controls
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (!_isRunning)
                  ElevatedButton.icon(
                    onPressed: _start,
                    icon: const Icon(LucideIcons.play),
                    label: const Text('شروع'),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(160, 56),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                  )
                else ...[
                  if (!_isPaused)
                    OutlinedButton.icon(
                      onPressed: _pause,
                      icon: const Icon(LucideIcons.pause),
                      label: const Text('توقف'),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(120, 52),
                      ),
                    )
                  else
                    ElevatedButton.icon(
                      onPressed: _resume,
                      icon: const Icon(LucideIcons.play),
                      label: const Text('ادامه'),
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(120, 52),
                      ),
                    ),
                  const SizedBox(width: 16),
                  ElevatedButton.icon(
                    onPressed: _finish,
                    icon: const Icon(LucideIcons.check),
                    label: const Text('پایان'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.success,
                      minimumSize: const Size(120, 52),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 48),
          ],
        ),
      ),
    );
  }
}

class _FinishSheet extends StatelessWidget {
  final int seconds;
  final TextEditingController testsController;
  final TextEditingController correctController;
  final TextEditingController wrongController;

  const _FinishSheet({
    required this.seconds,
    required this.testsController,
    required this.correctController,
    required this.wrongController,
  });

  @override
  Widget build(BuildContext context) {
    final mins = seconds ~/ 60;
    final secs = seconds % 60;

    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        left: 20,
        right: 20,
        top: 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('ثبت عملکرد', style: AppTypography.headingMedium),
          const SizedBox(height: 8),
          Text(
            'مدت واقعی: $mins دقیقه و $secs ثانیه',
            style: AppTypography.bodyMedium,
          ),
          const SizedBox(height: 20),
          TextField(
            controller: testsController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'تعداد تست'),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: correctController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'صحیح'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: wrongController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'غلط'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('ذخیره جلسه'),
            ),
          ),
        ],
      ),
    );
  }
}
