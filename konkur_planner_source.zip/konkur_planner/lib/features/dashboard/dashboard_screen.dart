import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/task.dart';
import '../../data/models/study_session.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  @override
  Widget build(BuildContext context) {
    final user = HiveService.currentUser;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final now = DateTime.now();
    final persianDate = _formatPersianDate(now);

    // Calculate today's stats
    final todayTasks = HiveService.tasks.values.where((t) {
      return t.scheduledDate.year == now.year &&
          t.scheduledDate.month == now.month &&
          t.scheduledDate.day == now.day;
    }).toList();

    final completedTasks = todayTasks.where((t) => t.status == TaskStatus.completed).length;
    final totalTasks = todayTasks.length;
    final progress = totalTasks > 0 ? completedTasks / totalTasks : 0.0;

    final todaySessions = HiveService.sessions.values.where((s) {
      return s.startedAt.year == now.year &&
          s.startedAt.month == now.month &&
          s.startedAt.day == now.day;
    }).toList();

    final studyMinutes = todaySessions.fold<int>(0, (sum, s) => sum + (s.durationSeconds ~/ 60));
    final studyHours = studyMinutes ~/ 60;
    final studyMins = studyMinutes % 60;
    final totalTests = todaySessions.fold<int>(0, (sum, s) => sum + s.testsDone);

    final capacity = user?.dailyStudyCapacityHours ?? 6.0;
    final capacityMinutes = (capacity * 60).toInt();
    final studyProgress = capacityMinutes > 0 ? (studyMinutes / capacityMinutes).clamp(0.0, 1.0) : 0.0;

    final streak = user?.currentStreak ?? 0;
    final name = user?.name ?? 'دانش‌آموز';

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'سلام $name 👋',
                              style: AppTypography.headingLarge.copyWith(
                                color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'آماده‌ای امروز یک قدم جلوتر بری؟',
                              style: AppTypography.bodyMedium.copyWith(
                                color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight,
                              ),
                            ),
                          ],
                        ),
                        // Streak badge
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            gradient: AppColors.streakGradient,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Text('🔥', style: TextStyle(fontSize: 16)),
                              const SizedBox(width: 4),
                              Text(
                                '$streak',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 14,
                                  fontFamily: null,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      persianDate,
                      style: AppTypography.caption.copyWith(
                        color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Main Progress Card
                    _TodayProgressCard(
                      studyHours: studyHours,
                      studyMins: studyMins,
                      targetHours: capacity,
                      progress: studyProgress,
                      tasksDone: completedTasks,
                      tasksTotal: totalTasks,
                      tests: totalTests,
                      isDark: isDark,
                    ),
                    const SizedBox(height: 20),

                    // Quick Stats Row
                    Row(
                      children: [
                        Expanded(
                          child: _MiniStatCard(
                            icon: LucideIcons.clock,
                            label: 'مطالعه امروز',
                            value: '${studyHours}س ${studyMins}د',
                            color: AppColors.primary,
                            isDark: isDark,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _MiniStatCard(
                            icon: LucideIcons.fileText,
                            label: 'تست امروز',
                            value: '$totalTests',
                            color: AppColors.secondary,
                            isDark: isDark,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _MiniStatCard(
                            icon: LucideIcons.checkCircle,
                            label: 'پیشرفت',
                            value: '${(progress * 100).toInt()}٪',
                            color: AppColors.accent,
                            isDark: isDark,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 28),

                    // Today's Plan Header
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'برنامه امروز',
                          style: AppTypography.headingMedium.copyWith(
                            color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
                          ),
                        ),
                        TextButton(
                          onPressed: () => context.go('/planner'),
                          child: const Text('مشاهده همه'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),
            ),

            // Today's Tasks Timeline
            if (todayTasks.isEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _EmptyPlanCard(isDark: isDark, onCreate: () => context.go('/planner')),
                ),
              )
            else
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final task = todayTasks[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                      child: _TaskTimelineCard(task: task, isDark: isDark),
                    );
                  },
                  childCount: todayTasks.length.clamp(0, 5),
                ),
              ),

            // Start Study Button
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
                child: ElevatedButton.icon(
                  onPressed: () => context.push('/timer'),
                  icon: const Icon(LucideIcons.play, size: 20),
                  label: const Text('شروع مطالعه'),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 56),
                    backgroundColor: AppColors.primary,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatPersianDate(DateTime date) {
    const weekdays = ['دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه', 'یکشنبه'];
    // Simple approximation - for production use persian_datetime_picker or similar
    final weekday = weekdays[date.weekday % 7];
    return '$weekday ${date.day} ${DateFormat.MMMM('fa').format(date)}';
  }
}

class _TodayProgressCard extends StatelessWidget {
  final int studyHours;
  final int studyMins;
  final double targetHours;
  final double progress;
  final int tasksDone;
  final int tasksTotal;
  final int tests;
  final bool isDark;

  const _TodayProgressCard({
    required this.studyHours,
    required this.studyMins,
    required this.targetHours,
    required this.progress,
    required this.tasksDone,
    required this.tasksTotal,
    required this.tests,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(0.35),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'پیشرفت امروز',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                        fontFamily: null,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '$studyHours ساعت و $studyMins دقیقه',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.w700,
                        fontFamily: null,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'هدف: ${targetHours.toStringAsFixed(1)} ساعت',
                      style: const TextStyle(
                        color: Colors.white60,
                        fontSize: 13,
                        fontFamily: null,
                      ),
                    ),
                  ],
                ),
              ),
              CircularPercentIndicator(
                radius: 48,
                lineWidth: 8,
                percent: progress,
                center: Text(
                  '${(progress * 100).toInt()}٪',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    fontFamily: null,
                  ),
                ),
                progressColor: Colors.white,
                backgroundColor: Colors.white.withOpacity(0.2),
                circularStrokeCap: CircularStrokeCap.round,
                animation: true,
                animationDuration: 800,
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _ProgressStat(label: 'کارها', value: '$tasksDone/$tasksTotal'),
                Container(width: 1, height: 28, color: Colors.white24),
                _ProgressStat(label: 'تست‌ها', value: '$tests'),
                Container(width: 1, height: 28, color: Colors.white24),
                _ProgressStat(label: 'پیشرفت', value: '${(progress * 100).toInt()}٪'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProgressStat extends StatelessWidget {
  final String label;
  final String value;

  const _ProgressStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            fontSize: 16,
            fontFamily: null,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 11,
            fontFamily: null,
          ),
        ),
      ],
    );
  }
}

class _MiniStatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  final bool isDark;

  const _MiniStatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? AppColors.borderDark : AppColors.borderLight,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(height: 10),
          Text(
            value,
            style: AppTypography.headingSmall.copyWith(
              color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: AppTypography.caption.copyWith(
              color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
            ),
          ),
        ],
      ),
    );
  }
}

class _TaskTimelineCard extends StatelessWidget {
  final StudyTask task;
  final bool isDark;

  const _TaskTimelineCard({required this.task, required this.isDark});

  @override
  Widget build(BuildContext context) {
    final isCompleted = task.status == TaskStatus.completed;
    final isMissed = task.status == TaskStatus.missed;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isCompleted
              ? AppColors.success.withOpacity(0.4)
              : isMissed
                  ? AppColors.error.withOpacity(0.4)
                  : (isDark ? AppColors.borderDark : AppColors.borderLight),
        ),
      ),
      child: Row(
        children: [
          // Time
          SizedBox(
            width: 52,
            child: Text(
              task.startTime,
              style: AppTypography.label.copyWith(
                color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight,
              ),
            ),
          ),
          // Indicator
          Container(
            width: 4,
            height: 48,
            decoration: BoxDecoration(
              color: isCompleted
                  ? AppColors.success
                  : isMissed
                      ? AppColors.error
                      : AppColors.primary,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 14),
          // Content
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  task.displayTitle,
                  style: AppTypography.headingSmall.copyWith(
                    color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
                    decoration: isCompleted ? TextDecoration.lineThrough : null,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${task.activity.emoji} ${task.activity.label} · ${task.durationMinutes} دقیقه'
                  '${task.targetTests != null ? ' · ${task.targetTests} تست' : ''}',
                  style: AppTypography.caption.copyWith(
                    color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
                  ),
                ),
              ],
            ),
          ),
          if (isCompleted)
            const Icon(LucideIcons.checkCircle2, color: AppColors.success, size: 22)
          else if (isMissed)
            const Icon(LucideIcons.xCircle, color: AppColors.error, size: 22),
        ],
      ),
    );
  }
}

class _EmptyPlanCard extends StatelessWidget {
  final bool isDark;
  final VoidCallback onCreate;

  const _EmptyPlanCard({required this.isDark, required this.onCreate});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isDark ? AppColors.borderDark : AppColors.borderLight,
        ),
      ),
      child: Column(
        children: [
          Icon(
            LucideIcons.calendarPlus,
            size: 48,
            color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
          ),
          const SizedBox(height: 16),
          Text(
            'هنوز برنامه‌ای برای امروز نداری',
            style: AppTypography.headingSmall.copyWith(
              color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'برنامه امروزت رو بساز و شروع کن',
            style: AppTypography.bodySmall.copyWith(
              color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: onCreate,
            icon: const Icon(LucideIcons.plus, size: 18),
            label: const Text('ساخت برنامه'),
          ),
        ],
      ),
    );
  }
}
