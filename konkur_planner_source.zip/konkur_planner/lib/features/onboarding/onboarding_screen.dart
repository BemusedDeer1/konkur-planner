import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/local/hive_service.dart';
import '../../data/models/user_profile.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final _pageController = PageController();
  int _currentPage = 0;

  // Form data
  final _nameController = TextEditingController();
  String _grade = 'دوازدهم';
  String _major = 'تجربی';
  double _dailyHours = 6.0;
  final _universityController = TextEditingController();
  final _targetMajorController = TextEditingController();

  final _pages = [
    _OnboardPage(
      emoji: '🎯',
      title: 'برنامه‌ریزی هوشمند',
      description: 'بر اساس زمان آزاد، سطح دروس و هدف کنکورت برنامه شخصی‌سازی‌شده بگیر.',
    ),
    _OnboardPage(
      emoji: '📝',
      title: 'مدیریت تست و مرور',
      description: 'تست‌ها رو ثبت کن، مباحث ضعیف رو پیدا کن و با سیستم مرور هوشمند فراموشی رو کم کن.',
    ),
    _OnboardPage(
      emoji: '📊',
      title: 'تحلیل پیشرفت',
      description: 'آمار دقیق مطالعه، درصدها و روند هفتگی رو ببین و نقاط ضعف رو هدف بگیر.',
    ),
    _OnboardPage(
      emoji: '🔥',
      title: 'رسیدن به هدف',
      description: 'با Streak، XP و اهداف روزانه/هفتگی انگیزه‌ات رو حفظ کن و تا روز کنکور پیش برو.',
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    _nameController.dispose();
    _universityController.dispose();
    _targetMajorController.dispose();
    super.dispose();
  }

  void _next() {
    if (_currentPage < _pages.length) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
      );
    } else {
      _finishOnboarding();
    }
  }

  Future<void> _finishOnboarding() async {
    if (_nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لطفاً نام خود را وارد کنید')),
      );
      return;
    }

    final profile = UserProfile(
      name: _nameController.text.trim(),
      grade: _grade,
      major: _major,
      targetUniversity: _universityController.text.trim(),
      targetMajor: _targetMajorController.text.trim(),
      dailyStudyCapacityHours: _dailyHours,
      onboardingCompleted: true,
    );

    await HiveService.saveUser(profile);
    if (mounted) {
      context.go('/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final isLastIntro = _currentPage == _pages.length - 1;
    final isForm = _currentPage == _pages.length;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Skip
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(
                onPressed: () {
                  _pageController.jumpToPage(_pages.length);
                },
                child: const Text('رد کردن'),
              ),
            ),
            Expanded(
              child: PageView(
                controller: _pageController,
                onPageChanged: (i) => setState(() => _currentPage = i),
                children: [
                  ..._pages.map((p) => _buildIntroPage(p, isDark)),
                  _buildFormPage(isDark),
                ],
              ),
            ),
            // Indicators + Button
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
              child: Column(
                children: [
                  if (!isForm)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(
                        _pages.length,
                        (i) => AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          width: _currentPage == i ? 24 : 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: _currentPage == i
                                ? AppColors.primary
                                : (isDark ? AppColors.borderDark : AppColors.borderLight),
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton(
                      onPressed: isForm ? _finishOnboarding : _next,
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      ),
                      child: Text(
                        isForm
                            ? 'شروع کنیم 🚀'
                            : isLastIntro
                                ? 'بریم پروفایل بسازیم'
                                : 'ادامه',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIntroPage(_OnboardPage page, bool isDark) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(page.emoji, style: const TextStyle(fontSize: 72)),
          const SizedBox(height: 32),
          Text(
            page.title,
            style: AppTypography.displayMedium.copyWith(
              color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          Text(
            page.description,
            style: AppTypography.bodyLarge.copyWith(
              color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildFormPage(bool isDark) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'پروفایل دانش‌آموز',
            style: AppTypography.headingLarge.copyWith(
              color: isDark ? AppColors.textPrimaryDark : AppColors.textPrimaryLight,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'این اطلاعات برای ساخت برنامه هوشمند استفاده می‌شود',
            style: AppTypography.bodyMedium.copyWith(
              color: isDark ? AppColors.textSecondaryDark : AppColors.textSecondaryLight,
            ),
          ),
          const SizedBox(height: 28),
          TextField(
            controller: _nameController,
            decoration: const InputDecoration(
              labelText: 'نام',
              hintText: 'مثلاً امیر',
            ),
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _grade,
            decoration: const InputDecoration(labelText: 'پایه تحصیلی'),
            items: ['دهم', 'یازدهم', 'دوازدهم', 'فارغ‌التحصیل']
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (v) => setState(() => _grade = v!),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _major,
            decoration: const InputDecoration(labelText: 'رشته'),
            items: ['تجربی', 'ریاضی', 'انسانی']
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (v) => setState(() => _major = v!),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _universityController,
            decoration: const InputDecoration(
              labelText: 'دانشگاه هدف (اختیاری)',
              hintText: 'مثلاً دانشگاه تهران',
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _targetMajorController,
            decoration: const InputDecoration(
              labelText: 'رشته هدف (اختیاری)',
              hintText: 'مثلاً پزشکی',
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'ظرفیت مطالعه روزانه: ${_dailyHours.toStringAsFixed(1)} ساعت',
            style: AppTypography.bodyMedium,
          ),
          Slider(
            value: _dailyHours,
            min: 2,
            max: 12,
            divisions: 20,
            label: '${_dailyHours.toStringAsFixed(1)} ساعت',
            onChanged: (v) => setState(() => _dailyHours = v),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

class _OnboardPage {
  final String emoji;
  final String title;
  final String description;

  _OnboardPage({
    required this.emoji,
    required this.title,
    required this.description,
  });
}
