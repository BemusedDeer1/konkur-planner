import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../data/local/hive_service.dart';
import '../../app.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = HiveService.currentUser;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final themeMode = ref.watch(themeModeProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('پروفایل')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Profile header
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: AppColors.primaryGradient,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundColor: Colors.white.withOpacity(0.2),
                  child: Text(
                    (user?.name.isNotEmpty == true) ? user!.name[0] : '؟',
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      fontFamily: null,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  user?.name ?? 'کاربر',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    fontFamily: null,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${user?.grade ?? ''} · ${user?.major ?? ''}',
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    fontFamily: null,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _ProfileBadge(
                      icon: '🔥',
                      label: '${user?.currentStreak ?? 0} روز',
                    ),
                    const SizedBox(width: 12),
                    _ProfileBadge(
                      icon: '⭐',
                      label: 'Level ${user?.level ?? 1}',
                    ),
                    const SizedBox(width: 12),
                    _ProfileBadge(
                      icon: '✨',
                      label: '${user?.xp ?? 0} XP',
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),

          // Settings
          Text('تنظیمات', style: AppTypography.headingMedium),
          const SizedBox(height: 12),
          _SettingsTile(
            icon: LucideIcons.user,
            title: 'ویرایش پروفایل',
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('در نسخه بعدی فعال می‌شود')),
              );
            },
            isDark: isDark,
          ),
          _SettingsTile(
            icon: LucideIcons.moon,
            title: 'حالت تاریک',
            trailing: Switch(
              value: themeMode == ThemeMode.dark ||
                  (themeMode == ThemeMode.system &&
                      MediaQuery.platformBrightnessOf(context) == Brightness.dark),
              onChanged: (v) {
                ref.read(themeModeProvider.notifier).state =
                    v ? ThemeMode.dark : ThemeMode.light;
              },
            ),
            isDark: isDark,
          ),
          _SettingsTile(
            icon: LucideIcons.bell,
            title: 'اعلان‌ها',
            onTap: () {},
            isDark: isDark,
          ),
          _SettingsTile(
            icon: LucideIcons.target,
            title: 'اهداف مطالعه',
            subtitle: '${user?.dailyStudyCapacityHours ?? 6} ساعت در روز',
            onTap: () {},
            isDark: isDark,
          ),
          _SettingsTile(
            icon: LucideIcons.bookOpen,
            title: 'دروس و منابع',
            onTap: () {},
            isDark: isDark,
          ),
          const SizedBox(height: 24),
          Text(
            'نسخه ۱.۰.۰ · ساخته‌شده با ❤️ برای کنکوری‌ها',
            style: AppTypography.caption.copyWith(
              color: isDark ? AppColors.textTertiaryDark : AppColors.textTertiaryLight,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

class _ProfileBadge extends StatelessWidget {
  final String icon;
  final String label;

  const _ProfileBadge({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(icon, style: const TextStyle(fontSize: 14)),
          const SizedBox(width: 4),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              fontFamily: null,
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool isDark;

  const _SettingsTile({
    required this.icon,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: isDark ? AppColors.surfaceElevatedDark : AppColors.surfaceLight,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isDark ? AppColors.borderDark : AppColors.borderLight,
        ),
      ),
      child: ListTile(
        leading: Icon(icon, size: 22, color: AppColors.primary),
        title: Text(title, style: AppTypography.bodyLarge),
        subtitle: subtitle != null ? Text(subtitle!, style: AppTypography.caption) : null,
        trailing: trailing ?? const Icon(LucideIcons.chevronLeft, size: 18),
        onTap: onTap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}
