import 'package:hive_flutter/hive_flutter.dart';
import '../models/user_profile.dart';
import '../models/subject.dart';
import '../models/task.dart';
import '../models/study_session.dart';
import '../models/goal.dart';

class HiveService {
  static const String userBox = 'user_profile';
  static const String subjectsBox = 'subjects';
  static const String tasksBox = 'tasks';
  static const String sessionsBox = 'study_sessions';
  static const String goalsBox = 'goals';

  static Future<void> init() async {
    await Hive.initFlutter();

    // Register adapters - for simplicity we use TypeAdapters generated later
    // In production run: flutter pub run build_runner build
    // For now we register manual adapters or use dynamic boxes

    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(UserProfileAdapter());
    }
    if (!Hive.isAdapterRegistered(1)) {
      Hive.registerAdapter(SubjectAdapter());
    }
    if (!Hive.isAdapterRegistered(2)) {
      Hive.registerAdapter(TaskActivityAdapter());
    }
    if (!Hive.isAdapterRegistered(3)) {
      Hive.registerAdapter(TaskStatusAdapter());
    }
    if (!Hive.isAdapterRegistered(4)) {
      Hive.registerAdapter(StudyTaskAdapter());
    }
    if (!Hive.isAdapterRegistered(5)) {
      Hive.registerAdapter(StudySessionAdapter());
    }
    if (!Hive.isAdapterRegistered(6)) {
      Hive.registerAdapter(GoalTypeAdapter());
    }
    if (!Hive.isAdapterRegistered(7)) {
      Hive.registerAdapter(GoalAdapter());
    }

    await Hive.openBox<UserProfile>(userBox);
    await Hive.openBox<Subject>(subjectsBox);
    await Hive.openBox<StudyTask>(tasksBox);
    await Hive.openBox<StudySession>(sessionsBox);
    await Hive.openBox<Goal>(goalsBox);
  }

  static Box<UserProfile> get user => Hive.box<UserProfile>(userBox);
  static Box<Subject> get subjects => Hive.box<Subject>(subjectsBox);
  static Box<StudyTask> get tasks => Hive.box<StudyTask>(tasksBox);
  static Box<StudySession> get sessions => Hive.box<StudySession>(sessionsBox);
  static Box<Goal> get goals => Hive.box<Goal>(goalsBox);

  static Future<void> seedDefaultSubjectsIfEmpty() async {
    if (subjects.isEmpty) {
      final defaults = Subject.defaultExperimental();
      for (final s in defaults) {
        await subjects.put(s.id, s);
      }
    }
  }

  static UserProfile? get currentUser {
    if (user.isEmpty) return null;
    return user.values.first;
  }

  static Future<void> saveUser(UserProfile profile) async {
    await user.put(profile.id, profile);
  }
}
