import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

part 'goal.g.dart';

@HiveType(typeId: 6)
enum GoalType {
  @HiveField(0)
  dailyHours,
  @HiveField(1)
  weeklyHours,
  @HiveField(2)
  monthlyHours,
  @HiveField(3)
  dailyTests,
  @HiveField(4)
  weeklyTests,
  @HiveField(5)
  monthlyTests,
}

@HiveType(typeId: 7)
class Goal extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  GoalType type;

  @HiveField(2)
  double targetValue;

  @HiveField(3)
  double currentValue;

  @HiveField(4)
  DateTime startDate;

  @HiveField(5)
  DateTime endDate;

  @HiveField(6)
  bool isActive;

  Goal({
    String? id,
    required this.type,
    required this.targetValue,
    this.currentValue = 0,
    required this.startDate,
    required this.endDate,
    this.isActive = true,
  }) : id = id ?? const Uuid().v4();

  double get progressPercent {
    if (targetValue <= 0) return 0;
    return (currentValue / targetValue * 100).clamp(0, 100);
  }

  String get label {
    switch (type) {
      case GoalType.dailyHours:
        return 'هدف روزانه مطالعه';
      case GoalType.weeklyHours:
        return 'هدف هفتگی مطالعه';
      case GoalType.monthlyHours:
        return 'هدف ماهانه مطالعه';
      case GoalType.dailyTests:
        return 'هدف روزانه تست';
      case GoalType.weeklyTests:
        return 'هدف هفتگی تست';
      case GoalType.monthlyTests:
        return 'هدف ماهانه تست';
    }
  }
}
