import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

part 'user_profile.g.dart';

@HiveType(typeId: 0)
class UserProfile extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  String grade; // پایه تحصیلی

  @HiveField(3)
  String major; // رشته: تجربی، ریاضی، انسانی

  @HiveField(4)
  String targetUniversity;

  @HiveField(5)
  String targetMajor;

  @HiveField(6)
  double dailyStudyCapacityHours; // ظرفیت مطالعه روزانه

  @HiveField(7)
  List<int> schoolDays; // 0=شنبه ... 6=جمعه

  @HiveField(8)
  String wakeTime; // "06:30"

  @HiveField(9)
  String sleepTime; // "23:00"

  @HiveField(10)
  int studyDaysPerWeek;

  @HiveField(11)
  int xp;

  @HiveField(12)
  int level;

  @HiveField(13)
  int currentStreak;

  @HiveField(14)
  int longestStreak;

  @HiveField(15)
  DateTime? lastStudyDate;

  @HiveField(16)
  bool onboardingCompleted;

  @HiveField(17)
  DateTime createdAt;

  @HiveField(18)
  DateTime updatedAt;

  UserProfile({
    String? id,
    required this.name,
    this.grade = 'دوازدهم',
    this.major = 'تجربی',
    this.targetUniversity = '',
    this.targetMajor = '',
    this.dailyStudyCapacityHours = 6.0,
    List<int>? schoolDays,
    this.wakeTime = '06:30',
    this.sleepTime = '23:00',
    this.studyDaysPerWeek = 6,
    this.xp = 0,
    this.level = 1,
    this.currentStreak = 0,
    this.longestStreak = 0,
    this.lastStudyDate,
    this.onboardingCompleted = false,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : id = id ?? const Uuid().v4(),
        schoolDays = schoolDays ?? [0, 1, 2, 3, 4],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  UserProfile copyWith({
    String? name,
    String? grade,
    String? major,
    String? targetUniversity,
    String? targetMajor,
    double? dailyStudyCapacityHours,
    List<int>? schoolDays,
    String? wakeTime,
    String? sleepTime,
    int? studyDaysPerWeek,
    int? xp,
    int? level,
    int? currentStreak,
    int? longestStreak,
    DateTime? lastStudyDate,
    bool? onboardingCompleted,
  }) {
    return UserProfile(
      id: id,
      name: name ?? this.name,
      grade: grade ?? this.grade,
      major: major ?? this.major,
      targetUniversity: targetUniversity ?? this.targetUniversity,
      targetMajor: targetMajor ?? this.targetMajor,
      dailyStudyCapacityHours: dailyStudyCapacityHours ?? this.dailyStudyCapacityHours,
      schoolDays: schoolDays ?? this.schoolDays,
      wakeTime: wakeTime ?? this.wakeTime,
      sleepTime: sleepTime ?? this.sleepTime,
      studyDaysPerWeek: studyDaysPerWeek ?? this.studyDaysPerWeek,
      xp: xp ?? this.xp,
      level: level ?? this.level,
      currentStreak: currentStreak ?? this.currentStreak,
      longestStreak: longestStreak ?? this.longestStreak,
      lastStudyDate: lastStudyDate ?? this.lastStudyDate,
      onboardingCompleted: onboardingCompleted ?? this.onboardingCompleted,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }
}
