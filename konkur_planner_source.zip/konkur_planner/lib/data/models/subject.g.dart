part of 'subject.dart';

class SubjectAdapter extends TypeAdapter<Subject> {
  @override
  final int typeId = 1;

  @override
  Subject read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Subject(
      id: fields[0] as String,
      name: fields[1] as String,
      iconName: fields[2] as String?,
      colorValue: fields[3] as int,
      isCustom: fields[4] as bool,
      masteryPercent: fields[5] as double,
      totalTests: fields[6] as int,
      correctTests: fields[7] as int,
      wrongTests: fields[8] as int,
      blankTests: fields[9] as int,
      lastStudiedAt: fields[10] as DateTime?,
      orderIndex: fields[11] as int,
      createdAt: fields[12] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, Subject obj) {
    writer
      ..writeByte(13)
      ..writeByte(0)..write(obj.id)
      ..writeByte(1)..write(obj.name)
      ..writeByte(2)..write(obj.iconName)
      ..writeByte(3)..write(obj.colorValue)
      ..writeByte(4)..write(obj.isCustom)
      ..writeByte(5)..write(obj.masteryPercent)
      ..writeByte(6)..write(obj.totalTests)
      ..writeByte(7)..write(obj.correctTests)
      ..writeByte(8)..write(obj.wrongTests)
      ..writeByte(9)..write(obj.blankTests)
      ..writeByte(10)..write(obj.lastStudiedAt)
      ..writeByte(11)..write(obj.orderIndex)
      ..writeByte(12)..write(obj.createdAt);
  }
}
