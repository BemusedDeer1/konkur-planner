import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

part 'study_session.g.dart';

@HiveType(typeId: 5)
class StudySession extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String? taskId;

  @HiveField(2)
  String subjectId;

  @HiveField(3)
  String subjectName;

  @HiveField(4)
  String? topicTitle;

  @HiveField(5)
  String activityLabel;

  @HiveField(6)
  DateTime startedAt;

  @HiveField(7)
  DateTime? endedAt;

  @HiveField(8)
  int durationSeconds;

  @HiveField(9)
  int testsDone;

  @HiveField(10)
  int correct;

  @HiveField(11)
  int wrong;

  @HiveField(12)
  int blank;

  @HiveField(13)
  double? difficulty;

  @HiveField(14)
  double? mastery;

  @HiveField(15)
  int xpEarned;

  StudySession({
    String? id,
    this.taskId,
    required this.subjectId,
    required this.subjectName,
    this.topicTitle,
    required this.activityLabel,
    required this.startedAt,
    this.endedAt,
    this.durationSeconds = 0,
    this.testsDone = 0,
    this.correct = 0,
    this.wrong = 0,
    this.blank = 0,
    this.difficulty,
    this.mastery,
    this.xpEarned = 0,
  }) : id = id ?? const Uuid().v4();

  double get accuracy {
    if (testsDone == 0) return 0;
    return (correct / testsDone) * 100;
  }
}
