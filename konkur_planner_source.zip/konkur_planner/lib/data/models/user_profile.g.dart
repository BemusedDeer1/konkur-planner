// MANUAL ADAPTER - in production use build_runner
part of 'user_profile.dart';

class UserProfileAdapter extends TypeAdapter<UserProfile> {
  @override
  final int typeId = 0;

  @override
  UserProfile read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return UserProfile(
      id: fields[0] as String,
      name: fields[1] as String,
      grade: fields[2] as String,
      major: fields[3] as String,
      targetUniversity: fields[4] as String,
      targetMajor: fields[5] as String,
      dailyStudyCapacityHours: fields[6] as double,
      schoolDays: (fields[7] as List).cast<int>(),
      wakeTime: fields[8] as String,
      sleepTime: fields[9] as String,
      studyDaysPerWeek: fields[10] as int,
      xp: fields[11] as int,
      level: fields[12] as int,
      currentStreak: fields[13] as int,
      longestStreak: fields[14] as int,
      lastStudyDate: fields[15] as DateTime?,
      onboardingCompleted: fields[16] as bool,
      createdAt: fields[17] as DateTime,
      updatedAt: fields[18] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, UserProfile obj) {
    writer
      ..writeByte(19)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.grade)
      ..writeByte(3)
      ..write(obj.major)
      ..writeByte(4)
      ..write(obj.targetUniversity)
      ..writeByte(5)
      ..write(obj.targetMajor)
      ..writeByte(6)
      ..write(obj.dailyStudyCapacityHours)
      ..writeByte(7)
      ..write(obj.schoolDays)
      ..writeByte(8)
      ..write(obj.wakeTime)
      ..writeByte(9)
      ..write(obj.sleepTime)
      ..writeByte(10)
      ..write(obj.studyDaysPerWeek)
      ..writeByte(11)
      ..write(obj.xp)
      ..writeByte(12)
      ..write(obj.level)
      ..writeByte(13)
      ..write(obj.currentStreak)
      ..writeByte(14)
      ..write(obj.longestStreak)
      ..writeByte(15)
      ..write(obj.lastStudyDate)
      ..writeByte(16)
      ..write(obj.onboardingCompleted)
      ..writeByte(17)
      ..write(obj.createdAt)
      ..writeByte(18)
      ..write(obj.updatedAt);
  }
}
