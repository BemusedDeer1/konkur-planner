part of 'study_session.dart';

class StudySessionAdapter extends TypeAdapter<StudySession> {
  @override
  final int typeId = 5;

  @override
  StudySession read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return StudySession(
      id: fields[0] as String,
      taskId: fields[1] as String?,
      subjectId: fields[2] as String,
      subjectName: fields[3] as String,
      topicTitle: fields[4] as String?,
      activityLabel: fields[5] as String,
      startedAt: fields[6] as DateTime,
      endedAt: fields[7] as DateTime?,
      durationSeconds: fields[8] as int,
      testsDone: fields[9] as int,
      correct: fields[10] as int,
      wrong: fields[11] as int,
      blank: fields[12] as int,
      difficulty: fields[13] as double?,
      mastery: fields[14] as double?,
      xpEarned: fields[15] as int,
    );
  }

  @override
  void write(BinaryWriter writer, StudySession obj) {
    writer
      ..writeByte(16)
      ..writeByte(0)..write(obj.id)
      ..writeByte(1)..write(obj.taskId)
      ..writeByte(2)..write(obj.subjectId)
      ..writeByte(3)..write(obj.subjectName)
      ..writeByte(4)..write(obj.topicTitle)
      ..writeByte(5)..write(obj.activityLabel)
      ..writeByte(6)..write(obj.startedAt)
      ..writeByte(7)..write(obj.endedAt)
      ..writeByte(8)..write(obj.durationSeconds)
      ..writeByte(9)..write(obj.testsDone)
      ..writeByte(10)..write(obj.correct)
      ..writeByte(11)..write(obj.wrong)
      ..writeByte(12)..write(obj.blank)
      ..writeByte(13)..write(obj.difficulty)
      ..writeByte(14)..write(obj.mastery)
      ..writeByte(15)..write(obj.xpEarned);
  }
}
