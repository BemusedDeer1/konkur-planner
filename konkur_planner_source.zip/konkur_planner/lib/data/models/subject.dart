import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

part 'subject.g.dart';

@HiveType(typeId: 1)
class Subject extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  String? iconName; // emoji or lucide name

  @HiveField(3)
  int colorValue;

  @HiveField(4)
  bool isCustom;

  @HiveField(5)
  double masteryPercent; // 0-100

  @HiveField(6)
  int totalTests;

  @HiveField(7)
  int correctTests;

  @HiveField(8)
  int wrongTests;

  @HiveField(9)
  int blankTests;

  @HiveField(10)
  DateTime? lastStudiedAt;

  @HiveField(11)
  int orderIndex;

  @HiveField(12)
  DateTime createdAt;

  Subject({
    String? id,
    required this.name,
    this.iconName,
    int? colorValue,
    this.isCustom = false,
    this.masteryPercent = 0,
    this.totalTests = 0,
    this.correctTests = 0,
    this.wrongTests = 0,
    this.blankTests = 0,
    this.lastStudiedAt,
    this.orderIndex = 0,
    DateTime? createdAt,
  })  : id = id ?? const Uuid().v4(),
        colorValue = colorValue ?? AppColors.biology.value,
        createdAt = createdAt ?? DateTime.now();

  Color get color => Color(colorValue);

  double get accuracy {
    if (totalTests == 0) return 0;
    return (correctTests / totalTests) * 100;
  }

  static List<Subject> defaultExperimental() {
    return [
      Subject(name: 'زیست‌شناسی', iconName: '🧬', colorValue: AppColors.biology.value, orderIndex: 0),
      Subject(name: 'شیمی', iconName: '🧪', colorValue: AppColors.chemistry.value, orderIndex: 1),
      Subject(name: 'فیزیک', iconName: '⚡', colorValue: AppColors.physics.value, orderIndex: 2),
      Subject(name: 'ریاضی', iconName: '📐', colorValue: AppColors.math.value, orderIndex: 3),
      Subject(name: 'زمین‌شناسی', iconName: '🌍', colorValue: AppColors.geology.value, orderIndex: 4),
    ];
  }
}
