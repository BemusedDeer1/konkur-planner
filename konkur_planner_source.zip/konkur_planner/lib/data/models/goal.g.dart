part of 'goal.dart';

class GoalTypeAdapter extends TypeAdapter<GoalType> {
  @override
  final int typeId = 6;

  @override
  GoalType read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0: return GoalType.dailyHours;
      case 1: return GoalType.weeklyHours;
      case 2: return GoalType.monthlyHours;
      case 3: return GoalType.dailyTests;
      case 4: return GoalType.weeklyTests;
      case 5: return GoalType.monthlyTests;
      default: return GoalType.dailyHours;
    }
  }

  @override
  void write(BinaryWriter writer, GoalType obj) {
    switch (obj) {
      case GoalType.dailyHours: writer.writeByte(0); break;
      case GoalType.weeklyHours: writer.writeByte(1); break;
      case GoalType.monthlyHours: writer.writeByte(2); break;
      case GoalType.dailyTests: writer.writeByte(3); break;
      case GoalType.weeklyTests: writer.writeByte(4); break;
      case GoalType.monthlyTests: writer.writeByte(5); break;
    }
  }
}

class GoalAdapter extends TypeAdapter<Goal> {
  @override
  final int typeId = 7;

  @override
  Goal read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Goal(
      id: fields[0] as String,
      type: fields[1] as GoalType,
      targetValue: fields[2] as double,
      currentValue: fields[3] as double,
      startDate: fields[4] as DateTime,
      endDate: fields[5] as DateTime,
      isActive: fields[6] as bool,
    );
  }

  @override
  void write(BinaryWriter writer, Goal obj) {
    writer
      ..writeByte(7)
      ..writeByte(0)..write(obj.id)
      ..writeByte(1)..write(obj.type)
      ..writeByte(2)..write(obj.targetValue)
      ..writeByte(3)..write(obj.currentValue)
      ..writeByte(4)..write(obj.startDate)
      ..writeByte(5)..write(obj.endDate)
      ..writeByte(6)..write(obj.isActive);
  }
}
